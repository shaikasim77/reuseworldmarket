# Roadmap & known limitations

## Done

- [x] Home page with hero, featured item, categories and how-it-works
- [x] Post an item — name, photo, description, location, category
- [x] Browse items in a photo grid with category filters
- [x] Sign up / login (email + password, Google), password reset
- [x] My Posts — manage your own listings
- [x] Row Level Security: public read, owner-only write
- [x] Photo storage with short-lived signed URLs
- [x] Navy + gold design system, fully responsive

## Next

- [ ] My Requests — full request/approve flow with notifications
- [ ] In-app chat between giver and receiver
- [ ] Search by keyword and filter by distance
- [ ] Multiple photos per item, plus item condition
- [ ] Profile pages with trust badges and handover history
- [ ] Report / flag an item

## Known limitations

- **Category list is fixed** by a database enum (`furniture`, `clothes`, `electronics`, `books`); adding one needs a migration.
- **No chat yet** — handover happens outside the app (phone or in person).
- **Photos are private-by-URL** (signed links valid for 1 hour); deep links to images expire.
- **No pagination** — browse loads every item, fine at hackathon scale, not at thousands of rows.
- **Email confirmation** must be configured in Supabase auth settings; without it, new users cannot log in.
