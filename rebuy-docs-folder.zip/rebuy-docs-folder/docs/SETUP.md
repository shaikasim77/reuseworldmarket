# Setup & run

## Requirements

- Node.js 20+ and npm
- A Supabase project (free tier is enough) with the `items` table and the `item-photos` bucket

## 1. Clone and install

```bash
git clone https://github.com/shaikasim77/reuseworldmarket.git
cd reuseworldmarket
npm install
```

## 2. Environment variables

Create a `.env` file in the project root. **Never commit it.**

```env
SUPABASE_PROJECT_ID=your-project-id
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxxxxxx
VITE_SUPABASE_PROJECT_ID=your-project-id
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxxxxxx
```

Where to find them: Supabase dashboard → **Project Settings → API** (Project URL and the publishable / anon key).

## 3. Database

Apply the schema from `drizzle/migrations/0000_create_items.sql` — either paste it into the Supabase **SQL Editor** and run it, or use the Drizzle CLI:

```bash
npx drizzle-kit push
```

That creates the `item_category` enum, the `items` table, the RLS policies and the `item-photos` storage policies.

## 4. Run

```bash
npm run dev        # local dev server
npm run build      # production build
npm test           # unit tests (vitest)
npm run lint       # eslint
```

## 5. Deploy

- **Lovable:** publish from the editor; every change is committed to this repository automatically.
- **Any Node host** (Vercel, Netlify, Railway…): build with `npm run build` and set the same environment variables in the host's dashboard.

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `Invalid login credentials` on login | The account does not exist or the password is different. If the account was created with Google, use **Forgot password** to set a password first. |
| Sign-up works but login fails | Email confirmation is on. Turn on **Auto-confirm email** in the auth settings, or confirm the user manually. |
| Photos do not appear | Check the `item-photos` bucket policies and that `photo_url` stores a path, not a full URL. |
| `Couldn't load items` on browse | The `items` table or its RLS policies are missing — re-run the migration. |
