# ♻️ Rebuy — One person's spare, another's need.

A free reuse marketplace: post the things you no longer need, and someone nearby gives them a second life.

**Live app:** https://reuseworldmarket.lovable.app
**Built for:** Hackathon 2026 · **Stack:** React 19 + TanStack Start · Tailwind CSS · Supabase

> Waste kadhu, Avakasam.

---

## 👀 For judges — start here

| Flow | What to do in the app | Code |
| --- | --- | --- |
| Post an item | Sign up → Post an item → photo, description, location, category | [`src/routes/post.tsx`](src/routes/post.tsx) |
| Browse items | Browse → filter by category | [`src/routes/browse.tsx`](src/routes/browse.tsx) |
| My listings | My Posts / My Requests (after login) | [`src/routes/my-posts.tsx`](src/routes/my-posts.tsx) |

## 📚 Documentation

| Document | What it covers |
| --- | --- |
| [**Frontend**](docs/FRONTEND.md) | Pages, components, design system, how data is fetched |
| [**Backend**](docs/BACKEND.md) | Database schema, RLS security, photo storage, auth, data flows |
| [Setup & run](docs/SETUP.md) | Run locally, environment variables, migrations, troubleshooting |
| [Roadmap](docs/ROADMAP.md) | What is done, what is next, known limitations |
| [Design system](design/DESIGN-SYSTEM.md) | Colour tokens, fonts, component and layout rules |
| [Screenshots](assets/screenshots) | App screenshots used in this README and in the pitch |

## 🧱 In one picture

```
FRONTEND (browser)                    BACKEND (Supabase)
React 19 + TanStack Start   ──HTTPS──► Auth      email/password + Google
Tailwind CSS + shadcn/ui              Postgres  table: items  (RLS enforced)
src/routes/ · src/components/         Storage   bucket: item-photos
```

No custom API server — Supabase is the backend, and Row Level Security enforces the rules inside the database. Full detail: [docs/FRONTEND.md](docs/FRONTEND.md) and [docs/BACKEND.md](docs/BACKEND.md).

## ✨ Features

- Post an item with photo, description, location and category
- Browse everything in a photo grid, filter by category
- Sign up / login (email + password, or Google), password reset
- My Posts — manage what you have listed · My Requests — track items you asked for
- Responsive, mobile-first layout with a navy + gold design system

## 📁 Repository map

```
README.md      this page
docs/          FRONTEND.md, BACKEND.md, SETUP.md, ROADMAP.md
docs/          setup, roadmap
design/        design system (colours, fonts, rules)
assets/        screenshots
src/           the app — routes (pages), components, styles, Supabase client
public/        static assets — logo, favicon, robots.txt
supabase/      Supabase project config
drizzle/       database schema + SQL migrations (the real schema lives here)
```

## 👥 Team

Built by **Shaik Asim** for the hackathon. Feedback welcome — open an issue.

---

Made with 💚 so that fewer usable things end up in a landfill.
