import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Recycle, MapPin, Sofa, Shirt, Laptop, BookOpen, PackageCheck, Users, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rebuy – One person's spare, another's need." },
      {
        name: "description",
        content:
          "Rebuy is a marketplace to give away furniture, clothes, electronics and books you no longer need — to people nearby.",
      },
      { property: "og:title", content: "Rebuy – One person's spare, another's need." },
      { property: "og:description", content: "Share items you no longer need with people nearby." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const stats = [
  { icon: PackageCheck, value: "4,218", label: "Items Reused" },
  { icon: Users, value: "1,204", label: "Givers" },
  { icon: Leaf, value: "12", label: "Cities" },
];

const cats = [
  { icon: Sofa, label: "Furniture" },
  { icon: Shirt, label: "Clothes" },
  { icon: Laptop, label: "Electronics" },
  { icon: BookOpen, label: "Books" },
];

const steps = [
  { num: "I", title: "Post it", text: "Photo, description, location" },
  { num: "II", title: "Someone finds it", text: "Browse or filter by category" },
  { num: "III", title: "Hand it over", text: "Reuse instead of waste" },
];

async function fetchFeatured() {
  const { data } = await supabase.from("items").select("*").order("created_at", { ascending: false }).limit(1);
  const item = data?.[0];
  if (!item) return null;
  let image: string | undefined;
  if (item.photo_url) {
    const { data: signed } = await supabase.storage.from("item-photos").createSignedUrl(item.photo_url, 3600);
    image = signed?.signedUrl;
  }
  return { ...item, image };
}

function Index() {
  const { data: featured } = useQuery({ queryKey: ["featured-item"], queryFn: fetchFeatured });

  return (
    <main className="min-h-[calc(100vh-97px)] bg-background pb-16">
      {/* ---------------- hero ---------------- */}
      <section className="mx-auto max-w-6xl px-4 pt-8">
        <div className="grid items-center gap-10 rounded-3xl bg-primary px-6 py-10 shadow-lift sm:px-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-14">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">Buy · Sell · Share · Give</p>
            <h1 className="mt-5 font-display text-4xl font-bold leading-[1.08] text-primary-foreground sm:text-6xl">
              Waste kadhu,
              <br />
              <span className="italic text-gold">Avakasam.</span>
            </h1>
            <div className="mt-6 flex items-center gap-3">
              <span className="h-px w-20 bg-gold/80" />
              <span className="h-2 w-2 rotate-45 bg-gold" />
              <span className="h-px flex-1 bg-primary-foreground/25" />
            </div>
            <p className="mt-6 font-display text-lg italic text-gold sm:text-xl">
              One person's spare, another's need.
            </p>
            <p className="mt-3 max-w-xl text-base leading-relaxed text-primary-foreground/80">
              Post what you no longer need — someone nearby gives it a second life.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" className="h-12 bg-gold text-gold-foreground hover:bg-gold/90">
                <Link to="/post">Post an Item</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 border-primary-foreground/40 bg-transparent text-primary-foreground hover:bg-primary-foreground/10 hover:text-primary-foreground"
              >
                <Link to="/browse">Browse Items</Link>
              </Button>
            </div>
          </div>

          {/* featured item card */}
          <div className="rounded-2xl border border-gold/50 bg-primary-foreground/5 p-3">
            <div className="rounded-xl border border-gold/25 p-3">
              <span className="inline-block rounded-md bg-gold px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-gold-foreground">
                Featured
              </span>
              <div className="relative mt-3 aspect-[4/3] overflow-hidden rounded-lg bg-primary-foreground/10">
                {featured?.image ? (
                  <img src={featured.image} alt={featured.name} className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full items-center justify-center px-4 text-center text-sm text-primary-foreground/60">
                    {featured ? featured.name : "No items yet — be the first to post!"}
                  </div>
                )}
                <span className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border border-gold bg-primary/60">
                  <Recycle className="h-4 w-4 text-gold" />
                </span>
              </div>
              <h2 className="mt-4 font-display text-xl font-bold text-primary-foreground">
                {featured?.name ?? "Wooden study table"}
              </h2>
              <p className="mt-1 text-sm capitalize text-primary-foreground/70">
                {featured ? `${featured.location} · ${featured.category} · Free` : "Kukatpally · Furniture · Free"}
              </p>
              <div className="my-4 h-px bg-gold/30" />
              <div className="flex items-start justify-between gap-4 text-xs">
                <div>
                  <p className="uppercase tracking-wider text-gold">From</p>
                  <p className="mt-1 text-primary-foreground/85">Shaik · 3 yrs used</p>
                </div>
                <div>
                  <p className="uppercase tracking-wider text-gold">To</p>
                  <p className="mt-1 text-primary-foreground/85">anyone nearby</p>
                </div>
              </div>
              <Button asChild size="sm" className="mt-5 w-full bg-gold text-gold-foreground hover:bg-gold/90">
                <Link to="/browse">Request item</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- stats ---------------- */}
      <section className="mx-auto mt-10 grid max-w-6xl grid-cols-1 gap-4 px-4 sm:grid-cols-3">
        {stats.map(({ icon: Icon, value, label }) => (
          <div
            key={label}
            className="flex items-center gap-4 rounded-2xl border border-border border-b-4 border-b-gold bg-card p-5 shadow-soft"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <Icon className="h-6 w-6 text-primary" />
            </span>
            <div>
              <p className="font-display text-3xl font-extrabold leading-none text-foreground">{value}</p>
              <p className="mt-1 text-sm text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </section>

      {/* ---------------- categories ---------------- */}
      <section className="mx-auto mt-6 grid max-w-6xl grid-cols-2 gap-4 px-4 sm:grid-cols-4">
        {cats.map(({ icon: Icon, label }) => (
          <Link
            key={label}
            to="/browse"
            className="flex items-center justify-center gap-2 rounded-2xl border border-border bg-card px-4 py-5 text-sm font-medium text-foreground shadow-soft transition-colors hover:border-gold"
          >
            <Icon className="h-5 w-5 text-primary" />
            {label}
          </Link>
        ))}
      </section>

      {/* ---------------- CTA ---------------- */}
      <section className="mx-auto mt-10 max-w-6xl px-4">
        <div className="flex flex-col items-start justify-between gap-5 rounded-2xl border border-gold/60 bg-accent p-7 sm:flex-row sm:items-center">
          <div>
            <p className="font-display text-2xl font-bold text-accent-foreground">
              Your unused things are someone's treasure.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Post your first item in under a minute — photo, description, location.
            </p>
          </div>
          <Button asChild size="lg" className="h-12 bg-gold text-gold-foreground hover:bg-gold/90">
            <Link to="/post">Post an Item</Link>
          </Button>
        </div>
      </section>

      {/* ---------------- how it works ---------------- */}
      <section className="mx-auto mt-12 max-w-6xl px-4">
        <h2 className="font-display text-3xl font-bold text-foreground">How it works</h2>
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {steps.map((s) => (
            <div key={s.num} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold font-display text-sm text-gold-deep">
                  {s.num}
                </span>
                <p className="font-display text-lg font-bold text-foreground">{s.title}</p>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" /> Everything is free — reuse instead of waste.
        </p>
      </section>
    </main>
  );
}
