import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Recycle, MapPin, Sofa, Shirt, Laptop, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rebuy – One person's spare, another's need." },
      {
        name: "description",
        content:
          "Rebuy is a marketplace to give away furniture, clothes, electronics and books you no longer need — to people nearby.",
      },
      { property: "og:title", content: "Rebuy – One person's spare, another's need." },
      { property: "og:description", content: "Share items you no longer need with people nearby." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const stats = [
  { value: "4,218", label: "items reused" },
  { value: "12", label: "cities" },
  { value: "1,204", label: "givers" },
  { value: "0", label: "items in landfill" },
];

const cats = [
  { icon: Sofa, label: "Furniture" },
  { icon: Shirt, label: "Clothes" },
  { icon: Laptop, label: "Electronics" },
  { icon: BookOpen, label: "Books" },
];

const steps = [
  { num: "I", title: "Post it", text: "Photo, description, location" },
  { num: "II", title: "Someone finds it", text: "Browse or filter by category" },
  { num: "III", title: "Hand it over", text: "Reuse instead of waste" },
];

async function fetchFeatured() {
  const { data } = await supabase.from("items").select("*").order("created_at", { ascending: false }).limit(1);
  const item = data?.[0];
  if (!item) return null;
  let image: string | undefined;
  if (item.photo_url) {
    const { data: signed } = await supabase.storage.from("item-photos").createSignedUrl(item.photo_url, 3600);
    image = signed?.signedUrl;
  }
  return { ...item, image };
}

function Index() {
  const { data: featured } = useQuery({ queryKey: ["featured-item"], queryFn: fetchFeatured });

  return (
    <main className="bg-hero min-h-[calc(100vh-57px)]">
      {/* ---------------- hero ---------------- */}
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pt-14 pb-10 lg:grid-cols-[1.1fr_0.9fr] lg:pt-20">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-primary">Buy · Sell · Share · Give</p>
          <h1 className="mt-5 font-display text-5xl font-bold leading-[1.05] text-foreground sm:text-6xl">
            Waste kadhu,
            <br />
            <span className="italic text-primary">Avakasam.</span>
          </h1>
          <div className="mt-6 flex items-center gap-3">
            <span className="h-px w-24 bg-primary/70" />
            <span className="h-2 w-2 rotate-45 bg-primary" />
            <span className="h-px flex-1 bg-primary/30" />
          </div>
          <p className="mt-6 font-display text-xl italic text-primary">One person's spare, another's need.</p>
          <p className="mt-3 max-w-xl text-base text-muted-foreground">
            Post what you no longer need — someone nearby gives it a second life.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/post">Post an Item</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/browse">Browse Items</Link>
            </Button>
          </div>
        </div>

        {/* featured card */}
        <div className="rounded-md border border-primary/70 bg-card p-3">
          <div className="rounded-sm border border-primary/25 p-3">
            <span className="inline-block rounded-sm bg-primary px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-primary-foreground">
              Featured
            </span>
            <div className="relative mt-3 aspect-[4/3] overflow-hidden rounded-sm bg-muted">
              {featured?.image ? (
                <img src={featured.image} alt={featured.name} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                  {featured ? featured.name : "No items yet"}
                </div>
              )}
              <span className="absolute right-3 top-3 flex h-10 w-10 items-center justify-center rounded-full border border-primary bg-background/70">
                <Recycle className="h-4 w-4 text-primary" />
              </span>
            </div>
            <h2 className="mt-4 font-display text-xl font-bold text-foreground">
              {featured?.name ?? "Wooden study table"}
            </h2>
            <p className="mt-1 text-sm capitalize text-muted-foreground">
              {featured ? `${featured.location} · ${featured.category} · Free` : "Kukatpally · Furniture · Free"}
            </p>
            <div className="my-4 h-px bg-primary/25" />
            <div className="flex items-end justify-between gap-4">
              <div className="text-xs">
                <p className="uppercase tracking-wider text-primary">From</p>
                <p className="mt-1 text-foreground">Shaik · 3 yrs used</p>
              </div>
              <div className="text-xs">
                <p className="uppercase tracking-wider text-primary">To</p>
                <p className="mt-1 text-foreground">anyone nearby</p>
              </div>
            </div>
            <Button asChild className="mt-5 w-full" size="sm">
              <Link to="/browse">Request item</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ---------------- stats ---------------- */}
      <section className="mx-auto max-w-6xl px-4">
        <div className="grid grid-cols-2 gap-y-6 border-y border-primary/25 py-6 sm:grid-cols-4 sm:divide-x sm:divide-primary/20">
          {stats.map((s) => (
            <div key={s.label} className="px-2 text-center sm:px-4">
              <p className="font-display text-3xl font-bold text-primary">{s.value}</p>
              <p className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- categories ---------------- */}
      <section className="mx-auto max-w-6xl px-4 py-10">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {cats.map(({ icon: Icon, label }) => (
            <Link
              key={label}
              to="/browse"
              className="flex items-center justify-center gap-2 rounded-md border border-border bg-card/60 px-4 py-4 text-sm text-foreground transition-colors hover:border-primary/60"
            >
              <Icon className="h-5 w-5 text-primary" />
              {label}
            </Link>
          ))}
        </div>
      </section>

      {/* ---------------- CTA ---------------- */}
      <section className="mx-auto max-w-6xl px-4 pb-10">
        <div className="flex flex-col items-start justify-between gap-5 rounded-md border border-primary/70 bg-secondary p-7 sm:flex-row sm:items-center">
          <div>
            <p className="font-display text-2xl font-bold text-foreground">
              Your unused things are someone's treasure.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Post your first item in under a minute — photo, description, location.
            </p>
          </div>
          <Button asChild size="lg">
            <Link to="/post">Post an Item</Link>
          </Button>
        </div>
      </section>

      {/* ---------------- how it works ---------------- */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="font-display text-3xl font-bold text-foreground">How it works</h2>
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {steps.map((s) => (
            <div key={s.num} className="rounded-md border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-full border border-primary font-display text-sm text-primary">
                  {s.num}
                </span>
                <p className="font-display text-lg font-bold text-foreground">{s.title}</p>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
        <p className="mt-8 flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 text-primary" /> Everything is free — reuse instead of waste.
        </p>
      </section>
    </main>
  );
}
